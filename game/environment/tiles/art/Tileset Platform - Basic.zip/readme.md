Thank you for downloading the assets!
-----

If you have any question please discuss on itch io page discussion or directly email to hello@theflavare.com . Any question and suggest are welcome.

Unity Demo project purpose to give example and demo from our assets. Please do not use this for your production.

## Heads Up!
- Tileset at 32x32
- All Demo Unity are using 2021.3.11f1

## Notes
1. You CAN use in your project in any commercial or non-commercial projects;
3. You CAN'T resold or redistributed this assets;
4. Credit appreciated;

## At least
Follow us more on Twitter @theflavare and Youtube @theflavare